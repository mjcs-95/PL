
#include <stdio.h>

int h2;

int pitagoras( int c1, int c2) {
    int temp, temp1, temp2;
    temp1 = c1 * c1;
    temp2 = c2 * c2;
    temp = temp1 + temp2;
    return temp;
}

int main(int argc, char const *argv[]) {
    int a, b;
    printf("tecla dos numeros: ");
    scanf("%d%d", &a, &b);
    h2=pitagoras(a, b);
    printf("La hipotenusa es %d\n", h2);

    return 0;
}
