
 #include <stdio.h>

int res;

int funcion(int param1, int param2) {
    int temp1;
    temp1 = param1 * param2 / 2;
    return temp1;
}

int main(){
    int temp1, temp2, temp3;

    printf("Introduzca dos valores enteros: ");

    scanf("%d%d", &temp1, &temp2);

    temp3 = 5 * temp1;

    res = funcion(temp3,temp2);

    printf("El resultado es: %d\n", res);
    return 0;
}
