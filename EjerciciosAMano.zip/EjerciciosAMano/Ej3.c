
#include <stdio.h>

int p, pm;

int porcentaje(int t, int n){
    int temp1, temp2;
    temp1 = t * n;
    temp2 = temp1 / 100;
    return temp2;
}

int main(int argc, char const *argv[]) {
    int h, m, ph;
    printf("Numero de personas: ");
    scanf("%d", &p);
    printf("Numero de hombre: ");
    scanf("%d", &h);
    printf("Numero de mujeres: ");
    scanf("%d", &m);

    pm = porcentaje(p, m);
    printf("El porcentaje de mujeres es %d\n", pm);
    ph = porcentaje(p, h);
    printf("El porcentaje de hombres es %d\n", ph);

    return 0;
}
