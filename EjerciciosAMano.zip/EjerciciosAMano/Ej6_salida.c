#include <stdio.h>

int b, B;

int funcion(int param1, int param2, int param3){
    int temp1;
    temp1 = param3 * (param2 + param1) / 2;
    return temp1;
}

int main(){
    int temp1,temp2;
    printf("Introduzca tres valores enteros: ");
    scanf("%d%d%d", &b, &B, &temp1);
    temp2 = funcion(b, B, temp1);
    printf("El resultado es: %d\n", temp2);
    return 0;
}
