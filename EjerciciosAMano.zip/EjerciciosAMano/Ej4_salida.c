#include <stdio.h>

int b;

int funcion(int param1, int param2){
    int temp1;
    temp1 = param1 * param2 / 2;
    return temp1;
}

int int main(){
    int temp1, temp2;
    printf("Introduzca dos valores entero: ");
    scanf("%d%d", &b, &temp1);
    temp2 = funcion(b, temp1);
    printf("El resultado es: %d\n", temp2);
    return 0;
}
