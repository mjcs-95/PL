
#include <stdio.h>

int d, t;

int velocidad(int d, int t){
    int temp;
    temp = d/t;
    return temp;
}

int main(){
    int v;
    printf("teclea dos numeros : ");
    scanf("%d%d", &d, &t);
    v = velocidad(d, t);
    printf("La velocidad es %d\n", v);

    return 0;
}
